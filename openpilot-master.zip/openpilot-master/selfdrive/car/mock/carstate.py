from openpilot.selfdrive.car.interfaces import CarStateBase

class CarState(CarStateBase):
  pass
