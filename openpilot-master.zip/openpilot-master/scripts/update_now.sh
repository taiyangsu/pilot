#!/usr/bin/env sh

# Send SIGHUP to updater
pkill -1 -f selfdrive.updated
